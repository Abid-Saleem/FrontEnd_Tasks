
jQuery(function () {
	initNav();	
	initAccordion();
	initTabs();	
	initFixedHeader();
	initSmoothScroll();
	initMapPoints();
	initSwiper(); 
	initIsotope();  
	initProgressBar(); 
	initFancybox();
	initOpenClose();
	initInputFocus();
	initAccordionNew();
	initCircleGraph();
});

$('#jobApplyFile').on('change',function(event){
	var name = event.target.files[0].name;
	$('#jobApplyFileName').text(name);
  })

// Windows Load AOS Init
$(window).on('load', function () {
	//jQuery('html').addClass('pageLoaded'); 
	initSlickSlides();
	AOS.init({ 
		once: true, 
	});
});

// Fancybox init
function initFancybox() {
	Fancybox.bind('[data-fancybox="projects"]', {
		
	});
}


// open-close init
function initOpenClose() {
	jQuery('.has-dropdown').openClose({
		hideOnClickOutside: true,
		activeClass: 'drop-active',
		opener: '.submenu-opener',
		slider: '.dropdown',
		animSpeed: 400,
		effect: 'slide'
	});

	jQuery('.mega-dropdown .tabsMainContent').openClose({
		hideOnClickOutside: true,
		activeClass: 'sublevel-active',
		opener: '.sublevel-opener',
		slider: '.sublevel-slide',
		animSpeed: 400,
		effect: 'slide'
	});

	jQuery('.sticky-contact-widget').openClose({
		hideOnClickOutside: true,
		activeClass: 'contact-widget-active',
		opener: '.contact-widget-opener, .number > .sidebar-contact-opener',
		slider: '.contact-widget-slide',
		animSpeed: 0,
		effect: 'none'
	});
}

function initInputFocus() {
	jQuery('.header-search .search-opener').click(function(){
		setTimeout(function() {
			$('.header-search .header-search-holder .form-control').focus();
		}, 100);
	});
}

// function progressbar
function initProgressBar() {
	var progressPath = document.querySelector(".back-to-top path");
	var pathLength = progressPath.getTotalLength();
	progressPath.style.transition = progressPath.style.WebkitTransition = "none";
	progressPath.style.strokeDasharray = pathLength + " " + pathLength;
	progressPath.style.strokeDashoffset = pathLength;
	progressPath.getBoundingClientRect();
	progressPath.style.transition = progressPath.style.WebkitTransition = "stroke-dashoffset 10ms linear";
	var updateProgress = function () {
		var scroll = $(window).scrollTop();
		var height = $(document).height() - $(window).height();
		var progress = pathLength - (scroll * pathLength) / height;
		progressPath.style.strokeDashoffset = progress;
	};
	updateProgress();
	$(window).scroll(updateProgress);
	var offset = 50;
	var duration = 550;
	jQuery(window).on("scroll", function () {
		if (jQuery(this).scrollTop() > offset) {
			jQuery(".back-to-top").addClass("active-progress");
		} else {
			jQuery(".back-to-top").removeClass("active-progress");
		}
	});
	jQuery(".back-to-top").on("click", function (event) {
		event.preventDefault();
		jQuery("html, body").animate({ scrollTop: 0 }, duration);
		return false;
	});    
}

// mobile menu init
function initNav() {
	$('.sidebar-contact .btn-call, .sidebar-contact-opener').click(function (e) {
		e.preventDefault();  
		$('html').toggleClass('sidebar-active'); 
	});
	$('.nav-opener, .nav-overlay').click(function (e) {
		e.preventDefault(); 
		$('html').toggleClass('nav-active');
	});
	$('.btnClose').click(function (e) {
		e.preventDefault();
		$('html').removeClass('nav-active');
	});

	$(function () {
		$('.nav ul li:has(.dropdown)').addClass('has-dropdown').prepend('<a href="javascript:;" class="drop-opener"><i class="fa fa-chevron-down"></i></a>');
		$('.drop-opener').click(function (e) {
			e.preventDefault();
			if ($(this).parent().hasClass('drop-active')) {
				$(this).parent().removeClass('drop-active');
			} else {
				$(this).parents('.nav').find('.drop-active').removeClass('drop-active');
				$(this).parent().addClass('drop-active');
			}
		});
	});


	// Header Search Function
	$('.header-search .search-opener, .header-search .search-close').click(function (e) {
		e.preventDefault();  
		$('html').toggleClass('header-search-active'); 
	});
}	



// Tabs 
function initTabs() {
	$(function () {
		$('.tabsMain').find('.tabContentActive').show(0);
		$('.tabsMain .tabOpener').click(function (e) {
			e.preventDefault();
			var getHash = $(this).attr('href');
			$(this).parents('.tabsMain').find('.tabActive').removeClass('tabActive'); 
			$(this).parents('.tabsMain').find('.tabsMainContent').hide().removeClass('tabContentActive');
			$(this).parent().addClass('tabActive');
			$(getHash).fadeIn().addClass('tabContentActive');
		});
	});

	// Mega Menu Tabs Function
	$(function () {
		$('.mega-dropdown').find('.tabContentActive').show(0);
		$('.mega-dropdown .megamenu-tabs li a').hover(function (e) {
			e.preventDefault();
			var getHash = $(this).attr('data-title');
			$(this).parents('.mega-dropdown').find('.tabActive').removeClass('tabActive'); 
			$(this).parents('.mega-dropdown').find('.tabsMainContent').hide(0).removeClass('tabContentActive');
			$(this).parent().addClass('tabActive');
			$(getHash).fadeIn(0).addClass('tabContentActive');
		});
	});

	// Process Function
	$(function () {
		$('.process-tabs').find('.process-image-active').show(0);
		$('.process-tabs .process-accordion .process-acc-opener').click(function (e) {
			e.preventDefault();
			var getHash = $(this).attr('href');
			$(this).parents('.process-tabs').find('.tabActive').removeClass('tabActive'); 
			$(this).parents('.process-tabs').find('.process-image-tab').hide().removeClass('process-image-active');
			$(this).parent().addClass('tabActive');
			$(getHash).fadeIn().addClass('process-image-active');
		});
	});
	
}

// Accordion 
function initAccordion() {
	$(function () {		
		$('.accordionMain .accordionOpener').click(function (e) {
			e.preventDefault() ;
			if ($(this).parent().parent().hasClass('accActive')) {
				$(this).parent().parent().removeClass('accActive');
				$(this).parent().next('.accContent').slideUp();
			} else {
				$(this).parents('.accordionMain').find('.accActive').removeClass('accActive');
				$(this).parents('.accordionMain').find('.accContent').slideUp();
				$(this).parent().parent().addClass('accActive'); 
				$(this).parent().next('.accContent').slideDown();
			}
		});
	});
}

// Slick Slider
function initSlickSlides() {
	jQuery('.filterControls').slick({
		slidesToScroll: 1,
		rows: 0,
		slidesToShow: 1, 
		prevArrow: $('.filtersSlidesMain .slick-prev'),
     	nextArrow: $('.filtersSlidesMain .slick-next'),  
		variableWidth: true,
		focusOnSelect: true,
		
		outerEdgeLimit: true,
		/*responsive: [
			{
				breakpoint: 1199,
				settings: {
					slidesToScroll: 1,
					slidesToShow: 5,
				}
			},
			{
				breakpoint: 1023,
				settings: {
					slidesToScroll: 1,
					slidesToShow: 4
				}
			},
			{
				breakpoint: 767,
				settings: {
					slidesToScroll: 1,
					slidesToShow: 2
				}
			},
			{
				breakpoint: 479,
				settings: {
					slidesToScroll: 1,
					slidesToShow: 1
				}
			}
		]*/
	});
	$('.portfolioSlider').slick({
		dots: true,
		arrows: false,
		slidesToShow: 3,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		  ]
	});
	$('.testimonialsSlider').slick({
		prevArrow: '<button class="slick-prev" type="button"><i class="fa fa-chevron-left"></i></button>',
		nextArrow: '<button class="slick-next" type="button"><i class="fa fa-chevron-right"></i></button>',
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
  		autoplaySpeed: 2000,
		responsive: [
			{
				breakpoint: 1199,
				settings: {
				  slidesToShow: 3,
				  slidesToScroll: 1
				}
			  },
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		  ]
	});
	$('.projectsSlider').slick({
		slidesToShow: 3,
		slidesToScroll: 1,
		autoplay: true,
  		autoplaySpeed: 2000, 
		infinite: true,
		prevArrow: '<button class="slick-prev" type="button"><i class="fa fa-chevron-left"></i></button>',
		nextArrow: '<button class="slick-next" type="button"><i class="fa fa-chevron-right"></i></button>',
		responsive: [
			{
				breakpoint: 1199,
				settings: {
				  slidesToShow: 2,
				  slidesToScroll: 1
				}
			  },
			{
			  breakpoint: 767,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		  ]
	});

	$('.logoesSlider').slick({
		prevArrow: '<button class="slick-prev" type="button"><i class="fa fa-chevron-left"></i></button>',
		nextArrow: '<button class="slick-next" type="button"><i class="fa fa-chevron-right"></i></button>',
		slidesToShow: 4,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 575,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			}
		  ]
	});

	
	$('.business-logos').slick({
		dots: false,
		arrows: false,
		slidesToShow: 4,
		slidesToScroll: 1,
		infinite: true,
		autoplay: true,
		autoplaySpeed: 3000,
		focusOnSelect: true, 
		variableWidth: true,
		pauseOnHover: false,
		responsive: [
			{
			  breakpoint: 1200,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 575,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			}
		  ]
	});

	
	$('.features-slider').slick({
		dots: true,
		arrows: false,
		slidesToShow: 4,
		slidesToScroll: 1,
		infinite: true,
		autoplay: true,
		autoplaySpeed: 3000,
		focusOnSelect: true,
		pauseOnHover: false,
		responsive: [
			{
			  breakpoint: 1200,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		  ]
	});

	
	$('.quotesSlider').slick({
		prevArrow: '<button class="slick-prev" type="button"><i class="fa fa-chevron-left"></i></button>',
		nextArrow: '<button class="slick-next" type="button"><i class="fa fa-chevron-right"></i></button>',
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: true,
		autoplay: true,
  		autoplaySpeed: 5000,
		fade: false,
		responsive: [
			
			{
			  breakpoint: 600,
			  settings: {
				arrows: false,
			  }
			}
		  ]
	});
}

// Fixed Header
function initFixedHeader() {
	$(window).scroll(function () {
		var sticky = $('html'),
			scroll = $(window).scrollTop();

		if (scroll >= 1) sticky.addClass('fixed-header');
		else sticky.removeClass('fixed-header');
	});
}

//Smooth Scrolling 
function initSmoothScroll() { 
	$('a.smoothScroll[href*="#"], .btn-explore')
	// Remove links that don't actually link to anything
		.not('[href="#"]')
		.not('[href="#0"]')
		.click(function(event) {
			// On-page links
			if (
			location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
			&& 
			location.hostname == this.hostname
			) {
			// Figure out element to scroll to
			var target = $(this.hash);
			target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
			// Does a scroll target exist?
			if (target.length) {
				// Only prevent default if animation is actually gonna happen
				event.preventDefault();
				$('html, body').animate({
				scrollTop: target.offset().top - 76
				}, 1000, function() {
				// Callback after animation
				// Must change focus!
				var $target = $(target);
				$target.focus();
				if ($target.is(":focus")) { // Checking if the target was focused
					return false;
				} else {
					$target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
					$target.focus(); // Set focus again
				};
				});
			}
		}
	});
}


// Map Points 
function initMapPoints() {
	$(function () {
		//$('.nav ul li:has(.dropdown)').addClass('has-dropdown').prepend('<a href="javascript:;" class="drop-opener"><i class="fa fa-chevron-down"></i></a>');
		$('.marker-link').click(function (e) {
			e.stopPropagation();
			if ($(this).parent().hasClass('pinActive')) {
				$(this).parent().removeClass('pinActive');
			} else {
				$(this).parents('.map-main').find('.pinActive').removeClass('pinActive');
				$(this).parent().addClass('pinActive');
			}
		});
		$(document).on("click", function(e) {
			if ($(e.target).is(".map-pin") === false) {
			  $(".map-pin").removeClass("pinActive");
			}
		  });
	});
}

// Swiper Slider 

function initSwiper() {
	var swiper2 = new Swiper(".swiperSlider2", {
		mousewheel: true,
		autoHeight: true,
		slidesPerView: "auto",
		freeMode: true,
		speed: 1500,		
		pauseOnMouseEnter: true,
		autoplay: {
		delay: 3000,
		},
		pagination: {
			el: ".swiper-pagination",
			type: "fraction",
		},
		effect: "fade",
		thumbs: {
			swiper: swiper,
		},
		scrollbar: {
			el: '.slider-scrollbar2',
			draggable: true,
			hide: false,
			snapOnRelease: true,
			dragSize: 46
		}
		
	});
	
	var swiper = new Swiper(".swiperSlider", {
		direction: "vertical",
		autoHeight: true,
		mousewheel: true,
		speed: 1500,
		slidesPerView: "auto",
		autoplay: {
			delay: 3000,
		},
		freeMode: true,

		thumbs: {
			swiper: swiper2,
		},
		pagination: {
			el: ".swiper-pagination",
			clickable: true,
		},
		scrollbar: {
			el: '.slider-scrollbar',
			draggable: true,
			hide: false,
			snapOnRelease: true,
			dragSize: 46
		}
	});
	var swiper3 = new Swiper(".swiperSlider2", {
		slidesPerView: "auto",
		autoHeight: true,
		freeMode: true,
		autoplay:true,
		mousewheel: true,
		effect: "fade",
		autoplay: {
			delay: 5000,
		  },
		thumbs: {
			swiper: swiper,
		},
		scrollbar: {
			el: '.slider-scrollbar2',
			draggable: true,
			hide: false,

			snapOnRelease: true,
			dragSize: 46
		},
		on: {
			init: function () {
				$('.js-current-slide').text(this.realIndex + 1);
				$('.js-all-slide').text(this.slides.length);
			}
		}
	});
	$(".swiper-scrollbar-drag").click(function(){
		if($(this).hasClass("swiper-paused")){			
			$(this).removeClass("swiper-paused");
			swiper.autoplay.start();
		}	else {	
			swiper.autoplay.stop();
			$(this).addClass("swiper-paused");
		}
	});
	// $(".swiperPlay").click(function(){
	// 	swiper.autoplay.start();
	// 	swiper2.autoplay.start();		
	// 	$(this).parent().removeClass('swiperAuto');		
	// });
	// $(".swiperStop").click(function(){
	// 	swiper.autoplay.stop();
	// 	swiper2.autoplay.stop();
	// 	$(this).parent().addClass('swiperAuto');	
	// });
}

// Isotope
function initIsotope() {
	$('.grid').isotope({
		itemSelector: '.item-grid',
		percentPosition: true,
		masonry: {
		  columnWidth: '.grid-sizer'
		}
	});


	// init Isotope
	var $grid = $('.portfolioGrid').isotope({
		itemSelector: '.mix',
		layoutMode: 'masonry'
		});
	
		// filter functions
		var filterFns = {
		// show if number is greater than 50
		numberGreaterThan50: function() {
			var number = $(this).find('.number').text();
			return parseInt( number, 10 ) > 50;
		},
		// show if name ends with -ium
		ium: function() {
			var name = $(this).find('.name').text();
			return name.match( /ium$/ );
		}
		};
	
		// bind filter button click
		$('#filters').on( 'click', 'button', function() {
		var filterValue = $( this ).attr('data-filter');
		// use filterFn if matches value
		filterValue = filterFns[ filterValue ] || filterValue;
		$grid.isotope({ filter: filterValue });
		});

		$('#filters').each( function( i, buttonGroup ) {
			var $buttonGroup = $( buttonGroup );
			$buttonGroup.on( 'click', 'button', function() {
			  $buttonGroup.find('.active').removeClass('active');
			  $( this ).addClass('active');
			});
		});
}

// Canvas Animation

// Canvas Animations
$(document).ready(function () {
	canvasAnimation();
}),
	$(window).resize(function () {
		canvasAnimation();
	});


// accordion menu init
function initAccordionNew() {
	jQuery('.process-accordion').slideAccordion({
		opener: '.process-acc-opener',
		slider: '.process-acc-slide',
		animSpeed: 300
	});
}

// initCircleGraph
function initCircleGraph() {
	$(".process-accordion").children().each(function () {
		$(".circle-container").append('<li><span></span></li>')
	});

	var count = parseInt($(".circle-container li").length);
      var circle_size = $(".circle-container").css("width").replace("px", "");
      circle_size = parseInt(circle_size) / 2 - 3;
      var angle = (360 / count);
      var rot = -90;
	  
      $(".circle-container").children().each(function () {
        $(this).css({"transform": "rotate( " + rot + "deg) translate(" + circle_size + "px)"});
        rot = rot + angle;
      });

	  var stroke_init = 100 / count;
      $('.circular-chart .circle').attr('stroke-dasharray', '' + stroke_init + ', 100')
     
	  // Observes Class changes to the Accordion items
      var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;

      var observer = new MutationObserver(function (mutations) {
		mutations.forEach(function (mutation) {
			if (mutation.target.getAttribute(mutation.attributeName) !== "process-accordion li" && mutation.target.getAttribute(mutation.attributeName) !== "process-accordion li") {
			var index = $(mutation.target).index();
			$(".circle-container").children().each(function () {
				if ($(this).index() <= index + 1) {
				$(this).addClass('circle-active');
				} else {
				$(this).removeClass('circle-active');
				}
			});
			var stroke_init = 100 / count;
			$(".circle-container").children().each(function () {
				if ($(this).index() <= index) {
				if (parseInt($(this).index()) !== 0) {
					var stroke = 100 / count * parseInt($(this).index()) + stroke_init;
					$('.circular-chart .circle').attr('stroke-dasharray', '' + stroke + ', 100')
				} else {
					$('.circular-chart .circle').attr('stroke-dasharray', '' + stroke_init + ', 100')
				}
				}
			});
			}
		});
	});

	$('.process-accordion li').on('click',function () {
		var index = $(this).index();
		$(".circle-container").children().each(function () {
			if ($(this).index() <= index + 1) {
			$(this).addClass('circle-active');
			} else {
			$(this).removeClass('circle-active');
			}
		});
		
		var stroke_init = 100 / count;
		$(".circle-container").children().each(function () {
			if ($(this).index() <= index) {
			if (parseInt($(this).index()) !== 0) {
				var stroke = 100 / count * parseInt($(this).index()) + stroke_init;
				$('.circular-chart .circle').attr('stroke-dasharray', '' + stroke + ', 100')
			} else {
				$('.circular-chart .circle').attr('stroke-dasharray', '' + stroke_init + ', 100')
			}
			}
		});
	});
}


/*
 * jQuery Open/Close plugin
 */
;(function($) {
	function OpenClose(options) {
		this.options = $.extend({
			addClassBeforeAnimation: true,
			hideOnClickOutside: false,
			activeClass:'active',
			opener:'.opener',
			slider:'.slide',
			animSpeed: 400,
			effect:'fade',
			event:'click'
		}, options);
		this.init();
	}
	OpenClose.prototype = {
		init: function() {
			if (this.options.holder) {
				this.findElements();
				this.attachEvents();
				this.makeCallback('onInit', this);
			}
		},
		findElements: function() {
			this.holder = $(this.options.holder);
			this.opener = this.holder.find(this.options.opener);
			this.slider = this.holder.find(this.options.slider);
		},
		attachEvents: function() {
			// add handler
			var self = this;
			this.eventHandler = function(e) {
				e.preventDefault();
				if (self.slider.hasClass(slideHiddenClass)) {
					self.showSlide();
				} else {
					self.hideSlide();
				}
			};
			self.opener.bind(self.options.event, this.eventHandler);

			// hover mode handler
			if (self.options.event === 'over') {
				self.opener.bind('mouseenter', function() {
					if (!self.holder.hasClass(self.options.activeClass)){
						self.showSlide();
					}
				});
				self.holder.bind('mouseleave', function() {
					self.hideSlide();
				});
			}

			// outside click handler
			self.outsideClickHandler = function(e) {
				if (self.options.hideOnClickOutside) {
					var target = $(e.target);
					if (!target.is(self.holder) && !target.closest(self.holder).length) {
						self.hideSlide();
					}
				}
			};

			// set initial styles
			if (this.holder.hasClass(this.options.activeClass)) {
				$(document).bind('click touchstart', self.outsideClickHandler);
			} else {
				this.slider.addClass(slideHiddenClass);
			}
		},
		showSlide: function() {
			var self = this;
			if (self.options.addClassBeforeAnimation) {
				self.holder.addClass(self.options.activeClass);
			}
			self.slider.removeClass(slideHiddenClass);
			$(document).bind('click touchstart', self.outsideClickHandler);

			self.makeCallback('animStart', true);
			toggleEffects[self.options.effect].show({
				box: self.slider,
				speed: self.options.animSpeed,
				complete: function() {
					if (!self.options.addClassBeforeAnimation) {
						self.holder.addClass(self.options.activeClass);
					}
					self.makeCallback('animEnd', true);
				}
			});
		},
		hideSlide: function() {
			var self = this;
			if (self.options.addClassBeforeAnimation) {
				self.holder.removeClass(self.options.activeClass);
			}
			$(document).unbind('click touchstart', self.outsideClickHandler);

			self.makeCallback('animStart', false);
			toggleEffects[self.options.effect].hide({
				box: self.slider,
				speed: self.options.animSpeed,
				complete: function() {
					if (!self.options.addClassBeforeAnimation) {
						self.holder.removeClass(self.options.activeClass);
					}
					self.slider.addClass(slideHiddenClass);
					self.makeCallback('animEnd', false);
				}
			});
		},
		destroy: function() {
			this.slider.removeClass(slideHiddenClass).css({ display:'' });
			this.opener.unbind(this.options.event, this.eventHandler);
			this.holder.removeClass(this.options.activeClass).removeData('OpenClose');
			$(document).unbind('click touchstart', this.outsideClickHandler);
		},
		makeCallback: function(name) {
			if (typeof this.options[name] === 'function') {
				var args = Array.prototype.slice.call(arguments);
				args.shift();
				this.options[name].apply(this, args);
			}
		}
	};

	// add stylesheet for slide on DOMReady
	var slideHiddenClass = 'js-slide-hidden';
	(function() {
		var tabStyleSheet = $('<style type="text/css">')[0];
		var tabStyleRule = '.' + slideHiddenClass;
		tabStyleRule += '{position:absolute !important;left:-9999px !important;top:-9999px !important;display:block !important}';
		if (tabStyleSheet.styleSheet) {
			tabStyleSheet.styleSheet.cssText = tabStyleRule;
		} else {
			tabStyleSheet.appendChild(document.createTextNode(tabStyleRule));
		}
		$('head').append(tabStyleSheet);
	}());

	// animation effects
	var toggleEffects = {
		slide: {
			show: function(o) {
				o.box.stop(true).hide().slideDown(o.speed, o.complete);
			},
			hide: function(o) {
				o.box.stop(true).slideUp(o.speed, o.complete);
			}
		},
		fade: {
			show: function(o) {
				o.box.stop(true).hide().fadeIn(o.speed, o.complete);
			},
			hide: function(o) {
				o.box.stop(true).fadeOut(o.speed, o.complete);
			}
		},
		none: {
			show: function(o) {
				o.box.hide().show(0, o.complete);
			},
			hide: function(o) {
				o.box.hide(0, o.complete);
			}
		}
	};

	// jQuery plugin interface
	$.fn.openClose = function(opt) {
		return this.each(function() {
			jQuery(this).data('OpenClose', new OpenClose($.extend(opt, { holder: this })));
		});
	};
}(jQuery));


/*
 * jQuery Accordion plugin
 */
;(function($){
	$.fn.slideAccordion = function(opt){
		// default options
		var options = $.extend({
			addClassBeforeAnimation: false,
			allowClickWhenExpanded: false,
			activeClass:'active',
			opener:'.opener',
			slider:'.slide',
			animSpeed: 300,
			collapsible:true,
			event:'click'
		},opt);

		return this.each(function(){
			// options
			var accordion = $(this);
			var items = accordion.find(':has('+options.slider+')');

			items.each(function(){
				var item = $(this);
				var opener = item.find(options.opener);
				var slider = item.find(options.slider);
				opener.bind(options.event, function(e){
					if(!slider.is(':animated')) {
						if(item.hasClass(options.activeClass)) {
							if(options.allowClickWhenExpanded) {
								return;
							} else if(options.collapsible) {
								slider.slideUp(options.animSpeed, function(){
									hideSlide(slider);
									item.removeClass(options.activeClass);
								});
							}
						} else {
							// show active
							var levelItems = item.siblings('.'+options.activeClass);
							var sliderElements = levelItems.find(options.slider);
							item.addClass(options.activeClass);
							showSlide(slider).hide().slideDown(options.animSpeed);
						
							// collapse others
							sliderElements.slideUp(options.animSpeed, function(){
								levelItems.removeClass(options.activeClass);
								hideSlide(sliderElements);
							});
						}
					}
					e.preventDefault();
				});
				if(item.hasClass(options.activeClass)) showSlide(slider); else hideSlide(slider);
			});
		});
	};

	// accordion slide visibility
	var showSlide = function(slide) {
		return slide.css({position:'', top: '', left: '', width: '' });
	};
	var hideSlide = function(slide) {
		return slide.show().css({position:'absolute', top: -9999, left: -9999, width: slide.width() });
	};
}(jQuery));